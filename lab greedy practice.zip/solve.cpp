#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<string>
#include<cmath>
#define loop(n) for(int i=0;i<n;i++)
#define loopj(n) for(int j=0;j<n;j++)
using namespace std;
#define sz 1000001

struct activity
{

    int id;
    int deadline;
    int profit;
    activity(int _id,int _deadline,int _profit)
    {
        id=_id;
        deadline=_deadline;
        profit=_profit;
    }
    bool operator >(const activity &a)const
    {
        if(a.deadline==deadline)
            return profit<a.profit;
        else
            return deadline<a.deadline;
    }

};

int main()
{

    freopen ("input.txt","r",stdin);
    int n;
    int a[1000];
    loop(1000){
        a[i]=-1;
    }
    vector<activity> vec;
    priority_queue<activity,vector<activity>,greater<activity> >q;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        int deadline;
        int profit;
        cin>>deadline;
        cin>>profit;
        q.push(activity(i,deadline,profit));



    }


    int last=q.top().deadline;
    while(!q.empty()){
        if(q.top().deadlinelast)
        a[last]=q.top().id;
        last--;
        q.pop();
    }
    loop(1000){
        if(a[i]!=-1)
        cout<<(char)(a[i]+'a')<<endl;
    }


    return 0;
}
