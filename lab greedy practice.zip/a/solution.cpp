#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<string>
#include<cmath>
#define loop(n) for(int i=0;i<n;i++)
using namespace std;
#define sz 1000001

struct activity
{
    int start;
    int stop;
    int in,serial;
    activity (){}
    activity(int _start,int _stop,int _in,int _serial)
    {
        start=_start;
        stop=_stop;
        in=_in;
        serial=_serial;
    }
    bool ov(activity a)
    {
        if(a.stop<=start)
            return false;
        if(stop<=a.start)
            return false;
        return true;
    }
    bool operator >(const activity &a)const
    {
        return stop<a.stop;
    }

};

int main()
{

    freopen ("input.txt","r",stdin);
    int n;
    priority_queue<activity,vector<activity>,greater<activity> >q;
    vector<activity> vec,ans;
    //cout<<"no of activity"<<endl;
    cin>>n;
    loop(n)
    {
        int start,stop;
        cin>>start>>stop;
        q.push(activity(start,stop,1,i));

    }
    while(! q.empty())
    {
        vec.push_back(q.top());
        q.pop();
    }
    activity a;

    for(int i=0;i<vec.size();)
    {
        a=vec[i];
        i++;
        while(a.ov(vec[i])){
            vec[i].in=0;
            i++;
        }
    }
    cout<<"{";
    for(int i=vec.size()-1;i>=0;i--){
        activity a= vec[i];
        if(a.in){
            cout<<a.serial<<",";
        }
    }
    cout<<"}"<<endl;

    return 0;
}
