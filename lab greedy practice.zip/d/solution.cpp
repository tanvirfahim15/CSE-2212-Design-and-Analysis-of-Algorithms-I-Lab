#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<string>
#include<cmath>
#define loop(n) for(int i=0;i<n;i++)
#define loopj(n) for(int j=0;j<n;j++)
using namespace std;
#define sz 10


int main()
{

    freopen ("input.txt","r",stdin);
    priority_queue<int,vector<int>,greater<int> >a,b;
    //vector<int> a,b;
    int n;
    cin>>n;
    loop(n)
    {
        int x;
        cin>>x;
        a.push(x);
    }
    loop(n)
    {
        int x;
        cin>>x;
        b.push(x);
    }
    int x=0;
    loop(n)
    {
        int ax=a.top();
        int bx=b.top();
        if(ax>bx)
            x+=(ax-bx);
        else

            x+=(bx-ax);
        a.pop();
        b.pop();
    }
    cout<<x<<endl;


    return 0;
}
