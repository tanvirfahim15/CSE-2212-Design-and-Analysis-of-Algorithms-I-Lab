#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<string>
#include<cmath>
#define loop(n) for(int i=0;i<n;i++)
#define loopj(n) for(int j=0;j<n;j++)
using namespace std;
#define sz 10


int main()
{

    freopen ("input.txt","r",stdin);
    int n;
    cin>>n;
    int a[sz];
    loop(sz){
       a[i]=0;
    }
    loop(n){
        int x;
        cin>>x;
        a[x]++;
    }
    loop(n){
        int x;
        cin>>x;
        a[x]--;
    }

    for(int i=1;i<sz;i++){
        a[i]+=a[i-1];
    }
    int mx=0;
    loop(sz){
        if(a[i]>mx)mx=a[i];
    }
    cout<<mx<<endl;




    return 0;
}
