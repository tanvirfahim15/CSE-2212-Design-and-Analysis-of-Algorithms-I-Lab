#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<string>
#include<cmath>
#define loop(n) for(int i=0;i<n;i++)
#define loopj(n) for(int j=0;j<n;j++)
using namespace std;
#define sz 1000001

struct activity
{

    int id;
    int deadline;
    int profit;
    activity(int _id,int _deadline,int _profit)
    {
        id=_id;
        deadline=_deadline;
        profit=_profit;
    }
    bool operator >(const activity &a)const
    {
        return profit<a.profit;
    }

};

int main()
{

    freopen ("input.txt","r",stdin);
    int n;
    vector<activity> vec;
    priority_queue<activity,vector<activity>,greater<activity> >q;
    cin>>n;
    loop(n)
    {
        int deadline;
        int profit;
        cin>>deadline;
        cin>>profit;
        q.push(activity(i,deadline,profit));


    }
    int a[sz];
    loop(sz){
        a[i]=-1;
    }
    while(!q.empty()){
        vec.push_back(q.top());
        q.pop();
    }
    loop(vec.size()){
        for(int k=vec[i].deadline;k>0;k--){
            if(a[k]==-1){
                a[k]=vec[i].id;
                break;
            }
        }
    }
    loop(sz){
        if(a[i]!=-1)cout<<(char)(a[i]+'a')<<" ";
    }



    return 0;
}
