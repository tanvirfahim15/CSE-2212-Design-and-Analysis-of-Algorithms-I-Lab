#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<string>
#include<cmath>
#define loop(n) for(int i=0;i<n;i++)
#define loopj(n) for(int j=0;j<n;j++)
using namespace std;
#define sz 10

struct activity
{
    int tme;
    int type;
    activity(int _tme, int _type){
        tme=_tme;
        type=_type;
    }
    bool operator >(const activity &a)const
    {
        if(a.tme==tme)
            return a.type<type;
        return a.tme<tme;
    }

};

int main()
{

    freopen ("input.txt","r",stdin);
    int n;
    cin>>n;
    priority_queue<activity,vector<activity>,greater<activity> >q;
    loop(n){
        int x;
        cin>>x;
        //cout<<x;
        q.push(activity(x,1));
    }
    loop(n){
        int x;
        cin>>x;

       // cout<<x;
        q.push(activity(x,2));
    }
    int ans=0,cur=0;
    while(!q.empty()){
        if(q.top().type==1)
            cur++;
        else
            cur--;
        if(ans<cur)ans=cur;
        q.pop();
    }
    cout<<ans;



    return 0;
}
